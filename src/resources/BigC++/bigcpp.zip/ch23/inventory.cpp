#include <iostream>
#include <list>

using namespace std;

/**
   Describes a product by identification number.
*/
class Product
{
public:
   Product(int id = 0);
   /**
      Gets the product identification number.
      @return the identification number
   */
   int get_id() const;
private:
   int identification_number;
};

inline int Product::get_id() const
{
   return identification_number;
}

inline ostream& operator<<(ostream& out, const Product& p)
{
   out << "Product " << p.get_id();
   return out;
}

inline Product::Product(int id)
{
   identification_number = id;
}

/**
   Maintains an inventory list of products on hand and back orders.
*/
class Inventory
{
public:
   /**
      Processes an order for a product with a given number.
      @param pid product id number
   */
   void order(int pid);

   /**
      Processes receipt of shipment for a product.
      @param newp new product
   */
   void receive(const Product& newp);
private:
   list<Product> on_hand;
   list<int> on_order;
};

void Inventory::order(int pid)
{
   cout << "Received order for product " << pid << "\n";
   list<Product>::iterator we_have = on_hand.begin();
   while (we_have != on_hand.end()) 
   {
      if (we_have->get_id() == pid)
      {
         // Have it, ship
         cout << "Ship " << *we_have << "\n";
         on_hand.erase(we_have);
         return;
      }
      ++we_have;
   }
   // Don't have it, back order
   cout << "Back order product " << pid << "\n";
   on_order.push_back(pid);
}

void Inventory::receive(const Product& newp)
{
   cout << "Received shipment of product " << newp << "\n";
   list<int>::iterator we_need = 
      find(on_order.begin(), on_order.end(), newp.get_id());
   if (we_need != on_order.end())
   {
      cout << "Ship " << newp << " to fill back order\n";
      on_order.erase(we_need);
   }
   else
      on_hand.push_front(newp);
}

int main()
{
   Inventory inv;
   inv.receive(Product(37));
   inv.receive(Product(14));
   inv.order(37);
   inv.order(37);
   inv.receive(Product(21));
   inv.order(14);
   inv.receive(Product(37));
   return 0;
}


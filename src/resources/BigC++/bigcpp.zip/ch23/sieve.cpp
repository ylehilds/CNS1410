#include <vector>
#include <iostream>

using namespace std;

int main()
{
   // Create the sieve, initially true
   const int sievesize = 100;
   vector<bool> sieve(sievesize, true);
   // Now search for positions with true
   for (int i = 2; i * i < sievesize; i++)
      if (sieve[i])
         // Strike out multiples
         for (int j = i + i; j < sievesize; j += i)
            sieve[j] = false;
   // Output values that remain set
   for (int i = 2; i < sievesize; i++)
      if (sieve[i])
         cout << i << " is prime\n";
   return 0;
}


#include "event.h"
#include <iostream>

using namespace std;

/**
   Simulation of a hot dog stand with limited seating.
*/
class HotDogStand : public Simulation 
{
public:
   HotDogStand(int s);
   /**
      Test to see if new customer can be seated.
      @return true if customer is seated
   */
   bool can_seat();

   /**
      Satisfied customer leaves, having eaten.
   */
   void customer_leaves();
private:
   int free_seats;
};

HotDogStand::HotDogStand(int s) : free_seats(s) {}

bool HotDogStand::can_seat()
{
   if (free_seats > 0) 
   {
      free_seats--;
      return true;
   }
   else
      return false;
}

void HotDogStand::customer_leaves() 
{
   free_seats++;
}

HotDogStand freds(3);

/**
   Arrival event for simulation.
   Either customer is seated, or leaves without eating.
*/
class ArriveEvent : public Event 
{
public:
   ArriveEvent(int t);
   virtual void do_event();
};

/**
   Leave event for simulation.
   Satisfied customer leaves and releases seat.
*/
class LeaveEvent : public Event 
{
public:
   LeaveEvent(int t);
   virtual void do_event();
};

ArriveEvent::ArriveEvent(int t) : Event(t) {}

void ArriveEvent::do_event()
{
   if (freds.can_seat()) 
   {
      cout << "time " << time << " Customer is seated\n";
      freds.schedule_event(new LeaveEvent(time + rand_int(1, 5)));
   }
   else
      cout << "time " << time 
         << " Customer is unable to find a seat, leaves\n";
}

LeaveEvent::LeaveEvent(int t) : Event(t) {}

void LeaveEvent::do_event()
{
   cout << "time " << time << " Customer finishes eating, leaves\n";
   freds.customer_leaves();
}

int main()
{
   for (int i = 0; i < 50; i++)
      freds.schedule_event(new ArriveEvent(rand_int(1, 60)));
   freds.run();
   return 0;
}

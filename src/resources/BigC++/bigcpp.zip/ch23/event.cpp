#include "event.h"

using namespace std;

void Simulation::run()
{
   while(!event_queue.empty()) 
   {
      Event* next_event = event_queue.top();
      event_queue.pop();
      next_event->do_event();
      delete next_event;
   }
}

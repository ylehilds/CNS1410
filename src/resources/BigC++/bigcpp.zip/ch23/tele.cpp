#include <string>
#include <iostream>
#include <map>

using namespace std;

/**
   TelephoneDirectory maintains a map of name/number pairs.
*/
class TelephoneDirectory 
{
public:
   /**
      Add a new name/number pair to database.
      @param name the new name
      @param number the new number
   */
   void add_entry(string name, int number);

   /**
      Find the number associated with a name.
      @param name the name being searched
      @return the associated number, or zero 
      if not found in database
   */
   int find_entry(string name) const;

   /**
      Print all entries on given output stream
      in name : number format ordered by name.
      @param out the output stream
   */
   void print_all(ostream& out) const;

   /**
      Print all entries on given output stream
      in number : name format ordered by number.
      @param out the output stream
   */
   void print_by_number(ostream& out) const;
private:
   map<string, int> database;
   typedef map<string, int>::const_iterator iterator;
};

void TelephoneDirectory::add_entry(string name, int number)
{
   database[name] = number;
}

int TelephoneDirectory::find_entry(string name) const
{
   iterator p = database.begin();
   if (p != database.end())
      return p->second;
   return 0; // not found
}

void TelephoneDirectory::print_all(ostream& out) const
{
   iterator current = database.begin();
   iterator stop = database.end();
   while (current != stop)
   {
      out << current->first << " : " << current->second << "\n";
      ++current;
   }
}

void TelephoneDirectory::print_by_number(ostream& out) const
{
   multimap<int, string> inverse_database;
   typedef multimap<int, string>::iterator miterator;
   iterator current = database.begin();
   iterator stop = database.end();
   while (current != stop)
   {
      inverse_database.insert(multimap<int, string>
         ::value_type(current->second, current->first));
      ++current;
   }
   miterator icurrent = inverse_database.begin();
   miterator istop = inverse_database.end();
   while (icurrent != istop)
   {
      cout << icurrent->first << " : " << icurrent->second << "\n";
      ++icurrent;
   }
}

int main()
{
   TelephoneDirectory data;
   data.add_entry("Fred", 7235591);
   data.add_entry("Mary", 3841212);
   data.add_entry("Sarah", 3841212);
   cout << "Number for Fred " << data.find_entry("Fred") << "\n";
   cout << "Printing by name \n";
   data.print_all(cout);
   cout << "Printing by number \n";
   data.print_by_number(cout);
   return 0;
}


#include <iomanip>
#include <sstream>

#include "matrix5.h"

string MatrixIndexException::format_message(int n)
{
   ostringstream outstr;
   outstr << "Matrix index " << n << " out of range";
   return outstr.str();
}
